package com.example.zillowclone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class AddPropertyActivity extends AppCompatActivity {

    EditText nameInput, locationInput, priceInput, bedsInput, bathsInput, sqftInput, descInput;
    ImageView imagePreview;
    MaterialButton addPropertyBtn, selectImageBtn;
    Uri selectedImageUri = null;
    DBHelper db;
    String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        boolean isDark = prefs.getBoolean("dark_mode", false);
        AppCompatDelegate.setDefaultNightMode(isDark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_property);

        db = new DBHelper(this);
        userEmail = getSharedPreferences("user", MODE_PRIVATE).getString("email", "default@example.com");

        nameInput = findViewById(R.id.nameInput);
        locationInput = findViewById(R.id.locationInput);
        priceInput = findViewById(R.id.priceInput);
        bedsInput = findViewById(R.id.bedsInput);
        bathsInput = findViewById(R.id.bathsInput);
        sqftInput = findViewById(R.id.sqftInput);
        descInput = findViewById(R.id.descInput);
        imagePreview = findViewById(R.id.imagePreview);
        addPropertyBtn = findViewById(R.id.addPropertyBtn);
        selectImageBtn = findViewById(R.id.selectImageBtn);

        selectImageBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            startActivityForResult(intent, 101);
        });

        addPropertyBtn.setOnClickListener(v -> {
            String name = nameInput.getText().toString();
            String location = locationInput.getText().toString();
            int price = Integer.parseInt(priceInput.getText().toString());
            int beds = Integer.parseInt(bedsInput.getText().toString());
            int baths = Integer.parseInt(bathsInput.getText().toString());
            int sqft = Integer.parseInt(sqftInput.getText().toString());
            String desc = descInput.getText().toString();

            String imageUrl = selectedImageUri != null ? selectedImageUri.toString() : "https://placehold.co/400x250?text=" + name;
            Property newProperty = new Property(0, name, location, price, beds, baths, sqft, desc, imageUrl);
            boolean success = db.addProperty(newProperty);

            Toast.makeText(this, success ? "Property Added" : "Failed to add property", Toast.LENGTH_SHORT).show();
            if (success) finish();
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101 && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            imagePreview.setImageURI(selectedImageUri);
        }
    }
}
