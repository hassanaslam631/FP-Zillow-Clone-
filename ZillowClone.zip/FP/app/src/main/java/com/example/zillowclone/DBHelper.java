package com.example.zillowclone;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.*;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "ZillowClone.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (email TEXT PRIMARY KEY, password TEXT)");
        db.execSQL("CREATE TABLE properties (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, location TEXT, price INTEGER, beds INTEGER, baths INTEGER, sqft INTEGER, description TEXT, imageUrl TEXT)");
        db.execSQL("CREATE TABLE favorites (id INTEGER PRIMARY KEY AUTOINCREMENT, userEmail TEXT, propertyId INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS properties");
        db.execSQL("DROP TABLE IF EXISTS favorites");
        onCreate(db);
    }

    public boolean insertUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("password", password);
        long result = db.insert("users", null, values);
        return result != -1;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE email=? AND password=?", new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean checkEmailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE email=?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public void insertDummyProperties() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM properties", null);
        if (cursor.getCount() > 0) return;

        db.execSQL("INSERT INTO properties (name, location, price, beds, baths, sqft, description, imageUrl) VALUES " +
                "('Luxury Villa', 'DHA Phase 5, Lahore', 120000000, 5, 6, 5000, 'Spacious villa with modern amenities.', 'https://placehold.co/400x250?text=Villa')," +
                "('Apartment in Gulberg', 'Gulberg III, Lahore', 45000000, 3, 3, 1800, 'Centrally located apartment.', 'https://placehold.co/400x250?text=Apartment')," +
                "('Commercial Plot', 'Johar Town, Lahore', 80000000, 0, 0, 10000, 'Prime location for business.', 'https://placehold.co/400x250?text=Plot');");

        cursor.close();
    }

    public boolean addProperty(Property property) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", property.getName());
        values.put("location", property.getLocation());
        values.put("price", property.getPrice());
        values.put("beds", property.getBeds());
        values.put("baths", property.getBaths());
        values.put("sqft", property.getSqft());
        values.put("description", property.getDescription());
        values.put("imageUrl", property.getImageUrl());
        long result = db.insert("properties", null, values);
        return result != -1;
    }

    public List<Property> getAllProperties() {
        List<Property> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM properties", null);
        while (cursor.moveToNext()) {
            list.add(new Property(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getInt(3),
                    cursor.getInt(4),
                    cursor.getInt(5),
                    cursor.getInt(6),
                    cursor.getString(7),
                    cursor.getString(8)
            ));
        }
        cursor.close();
        return list;
    }

    public boolean toggleFavorite(String email, int propertyId) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM favorites WHERE userEmail=? AND propertyId=?", new String[]{email, String.valueOf(propertyId)});
        if (cursor.moveToFirst()) {
            db.delete("favorites", "userEmail=? AND propertyId=?", new String[]{email, String.valueOf(propertyId)});
            cursor.close();
            return false;
        } else {
            ContentValues values = new ContentValues();
            values.put("userEmail", email);
            values.put("propertyId", propertyId);
            db.insert("favorites", null, values);
            cursor.close();
            return true;
        }
    }

    public Set<Integer> getUserFavoriteIds(String email) {
        Set<Integer> favorites = new HashSet<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT propertyId FROM favorites WHERE userEmail=?", new String[]{email});
        while (cursor.moveToNext()) {
            favorites.add(cursor.getInt(0));
        }
        cursor.close();
        return favorites;
    }
}
