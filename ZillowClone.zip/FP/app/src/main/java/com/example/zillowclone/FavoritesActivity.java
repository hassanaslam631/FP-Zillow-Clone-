package com.example.zillowclone;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class FavoritesActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    SwipeRefreshLayout swipeRefresh;
    List<Property> favoriteProps;
    PropertyAdapter adapter;
    DBHelper db;
    String userEmail;
    Set<Integer> favIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        boolean isDark = prefs.getBoolean("dark_mode", false);
        AppCompatDelegate.setDefaultNightMode(isDark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // using same layout

        db = new DBHelper(this);
        userEmail = getSharedPreferences("user", MODE_PRIVATE).getString("email", "default@example.com");
        favIds = db.getUserFavoriteIds(userEmail);

        favoriteProps = new ArrayList<>();
        for (Property p : db.getAllProperties()) {
            if (favIds.contains(p.getId())) favoriteProps.add(p);
        }

        recyclerView = findViewById(R.id.recyclerView);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        adapter = new PropertyAdapter(this, favoriteProps, favIds, userEmail, db);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(() -> {
            refreshFavorites();
            swipeRefresh.setRefreshing(false);
        });
    }

    private void refreshFavorites() {
        favIds = db.getUserFavoriteIds(userEmail);
        favoriteProps.clear();
        for (Property p : db.getAllProperties()) {
            if (favIds.contains(p.getId())) favoriteProps.add(p);
        }
        adapter.notifyDataSetChanged();
    }
}
