package com.example.zillowclone;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    PropertyAdapter adapter;
    DBHelper db;
    String userEmail = "user@example.com"; // for now
    Set<Integer> favorites = new HashSet<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        db = new DBHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Property> propertyList = getDummyProperties();

        adapter = new PropertyAdapter(this, propertyList, favorites, userEmail, db);
        recyclerView.setAdapter(adapter);
    }

    private List<Property> getDummyProperties() {
        List<Property> list = new ArrayList<>();
        list.add(new Property(1, "Luxury Villa", "DHA Phase 5, Lahore", 120000000, 5, 6, 5000, "https://placehold.co/400x250/E0E7FF/4338CA?text=Villa"));
        list.add(new Property(2, "Studio Apartment", "Bahria Town, Lahore", 15000000, 1, 1, 600, "https://placehold.co/400x250/E0E7FF/4338CA?text=Studio"));
        list.add(new Property(3, "Farmhouse", "Raiwind Road", 75000000, 4, 5, 8000, "https://placehold.co/400x250/E0E7FF/4338CA?text=Farmhouse"));
        list.add(new Property(4, "Commercial Plot", "Johar Town", 80000000, 0, 0, 10000, "https://placehold.co/400x250/E0E7FF/4338CA?text=Plot"));
        list.add(new Property(5, "Gulberg Apartment", "Gulberg III", 45000000, 3, 3, 1800, "https://placehold.co/400x250/E0E7FF/4338CA?text=Apartment"));
        return list;
    }
}
