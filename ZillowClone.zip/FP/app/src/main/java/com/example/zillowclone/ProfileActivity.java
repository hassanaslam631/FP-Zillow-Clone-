package com.example.zillowclone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;

public class ProfileActivity extends AppCompatActivity {

    TextView emailView;
    Button logoutButton;
    SwitchCompat themeSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        boolean isDark = prefs.getBoolean("dark_mode", false);
        AppCompatDelegate.setDefaultNightMode(isDark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        emailView = findViewById(R.id.emailView);
        logoutButton = findViewById(R.id.logoutButton);
        themeSwitch = findViewById(R.id.themeSwitch);

        SharedPreferences userPrefs = getSharedPreferences("user", MODE_PRIVATE);
        String email = userPrefs.getString("email", "N/A");
        emailView.setText("Logged in as: " + email);

        themeSwitch.setChecked(isDark);
        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("dark_mode", isChecked);
            editor.apply();

            AppCompatDelegate.setDefaultNightMode(
                    isChecked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
            );
            recreate(); // refresh theme
        });

        logoutButton.setOnClickListener(v -> {
            userPrefs.edit().clear().apply();
            startActivity(new Intent(this, LoginActivity.class));
            finishAffinity();
        });
    }
}
