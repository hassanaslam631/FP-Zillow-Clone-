package com.example.zillowclone;

public class Property {
    private int id;
    private String name, location, description, imageUrl;
    private int price, beds, baths, sqft;

    public Property(int id, String name, String location, int price, int beds, int baths, int sqft, String description, String imageUrl) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.price = price;
        this.beds = beds;
        this.baths = baths;
        this.sqft = sqft;
        this.description = description;
        this.imageUrl = imageUrl;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getLocation() { return location; }
    public int getPrice() { return price; }
    public int getBeds() { return beds; }
    public int getBaths() { return baths; }
    public int getSqft() { return sqft; }
    public String getDescription() { return description; }
    public String getImageUrl() { return imageUrl; }
}
