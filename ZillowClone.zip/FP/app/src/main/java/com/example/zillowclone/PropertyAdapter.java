package com.example.zillowclone;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.text.NumberFormat;
import java.util.List;
import java.util.Set;

public class PropertyAdapter extends RecyclerView.Adapter<PropertyAdapter.PropertyViewHolder> {

    private Context context;
    private List<Property> propertyList;
    private Set<Integer> favorites;
    private String userEmail;
    private DBHelper db;

    public PropertyAdapter(Context context, List<Property> propertyList, Set<Integer> favorites, String userEmail, DBHelper db) {
        this.context = context;
        this.propertyList = propertyList;
        this.favorites = favorites;
        this.userEmail = userEmail;
        this.db = db;
    }

    @NonNull
    @Override
    public PropertyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.property_item, parent, false);
        return new PropertyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PropertyViewHolder holder, int position) {
        Property p = propertyList.get(position);
        holder.name.setText(p.getName());
        holder.location.setText(p.getLocation());
        holder.price.setText("PKR " + NumberFormat.getInstance().format(p.getPrice()));

        Glide.with(context)
                .load(p.getImageUrl())
                .placeholder(R.drawable.placeholder)
                .into(holder.imageView);

        boolean isFav = favorites.contains(p.getId());
        holder.favoriteBtn.setImageResource(isFav ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);

        holder.favoriteBtn.setOnClickListener(v -> {
            boolean nowFav = db.toggleFavorite(userEmail, p.getId());
            if (nowFav) {
                favorites.add(p.getId());
                holder.favoriteBtn.setImageResource(R.drawable.ic_heart_filled);
            } else {
                favorites.remove(p.getId());
                holder.favoriteBtn.setImageResource(R.drawable.ic_heart_outline);
            }
        });
    }

    @Override
    public int getItemCount() {
        return propertyList.size();
    }

    public static class PropertyViewHolder extends RecyclerView.ViewHolder {
        TextView name, location, price;
        ImageButton favoriteBtn;
        ImageView imageView;

        public PropertyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            location = itemView.findViewById(R.id.location);
            price = itemView.findViewById(R.id.price);
            imageView = itemView.findViewById(R.id.imageView);
            favoriteBtn = itemView.findViewById(R.id.favoriteBtn);
        }
    }
}
