package com.example.zillowclone;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.room.Room;

import com.example.zillowclone.data.AppDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ZillowCloneApp extends Application {
    private static final int NUMBER_OF_THREADS = 4;
    // Executor service for database operations
    public final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);
    private AppDatabase database;
    private static ZillowCloneApp instance;

    public static final String PREFS_NAME = "settings";
    public static final String PREF_DARK_MODE = "dark_mode";
    public static final String PREF_USER_EMAIL = "user_email";


    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        // Initialize Room database
        database = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "zillow-clone-db")
                .fallbackToDestructiveMigration() // Handle migrations simply for now
                .build();

        // Apply theme settings
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isDarkMode = prefs.getBoolean(PREF_DARK_MODE, false);
        AppCompatDelegate.setDefaultNightMode(
                isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
        );
    }

    public static ZillowCloneApp getInstance() {
        return instance;
    }

    public AppDatabase getDatabase() {
        return database;
    }
}
