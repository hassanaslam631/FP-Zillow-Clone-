package com.example.zillowclone.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.zillowclone.data.dao.PropertyDao;
import com.example.zillowclone.data.dao.UserDao;
import com.example.zillowclone.data.model.Property;
import com.example.zillowclone.data.model.User;

// Room database definition
@Database(entities = {User.class, Property.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // Abstract method to get the UserDao
    public abstract UserDao userDao();

    // Abstract method to get the PropertyDao
    public abstract PropertyDao propertyDao();
}
