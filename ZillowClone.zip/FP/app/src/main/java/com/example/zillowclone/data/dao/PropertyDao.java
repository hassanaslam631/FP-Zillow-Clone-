package com.example.zillowclone.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.zillowclone.data.model.Property;
import com.google.common.util.concurrent.ListenableFuture;


import java.util.List;

// Data Access Object for Properties
@Dao
public interface PropertyDao {

    // Insert a property. If there's a conflict (e.g., same ID), replace it.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Property property);

    // Insert multiple properties
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Property> properties);

    // Update an existing property
    @Update
    void update(Property property);

    // Get all properties as LiveData (observes changes)
    @Query("SELECT * FROM properties ORDER BY id DESC")
    LiveData<List<Property>> getAllProperties();

    // Get properties marked as favorite by a specific user
    @Query("SELECT * FROM properties WHERE isFavorite = 1 AND userEmail = :userEmail ORDER BY id DESC")
    LiveData<List<Property>> getFavoriteProperties(String userEmail);

    // Get a single property by its ID (returns LiveData)
    @Query("SELECT * FROM properties WHERE id = :propertyId")
    LiveData<Property> getPropertyById(int propertyId);

    // Get a single property by its ID (returns ListenableFuture for async one-shot operations)
    @Query("SELECT * FROM properties WHERE id = :propertyId")
    ListenableFuture<Property> getPropertyByIdFuture(int propertyId);


    // Search properties by name or location (case-insensitive)
    @Query("SELECT * FROM properties WHERE name LIKE :query OR location LIKE :query ORDER BY id DESC")
    LiveData<List<Property>> searchProperties(String query);

    // Delete a property by ID (useful if needed)
    @Query("DELETE FROM properties WHERE id = :propertyId")
    void deletePropertyById(int propertyId);

    // Clear all properties (useful for debugging or reset)
    @Query("DELETE FROM properties")
    void clearAllProperties();
}
