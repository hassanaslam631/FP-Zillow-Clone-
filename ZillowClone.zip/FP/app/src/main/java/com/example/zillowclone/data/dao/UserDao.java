package com.example.zillowclone.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.zillowclone.data.model.User;
// Corrected import for ListenableFuture
import com.google.common.util.concurrent.ListenableFuture;

// Data Access Object for Users
@Dao
public interface UserDao {

    // Insert a user. If there's a conflict (e.g., same email), abort.
    @Insert(onConflict = OnConflictStrategy.ABORT)
    void insert(User user);

    // Get a user by email and password (for login)
    // Uses ListenableFuture for asynchronous one-shot query
    @Query("SELECT * FROM users WHERE email = :email AND password = :password")
    ListenableFuture<User> getUser(String email, String password);

    // Get a user by email (to check if email exists during signup)
    // Uses ListenableFuture for asynchronous one-shot query
    @Query("SELECT * FROM users WHERE email = :email")
    ListenableFuture<User> getUserByEmail(String email);
}
