package com.example.zillowclone.data.model;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

// Marks this class as a Room entity (table)
@Entity(tableName = "properties")
public class Property {
    @PrimaryKey(autoGenerate = true)
    private int id; // Unique ID for the property, auto-generated

    private String name;
    private String location;
    private int price;
    private int beds;
    private int baths;
    private int sqft;
    private String description;
    private String imageUrl; // URL or URI string for the property image
    private boolean isFavorite; // Flag to indicate if the property is a favorite
    private String userEmail; // Email of the user who might have favorited or added this

    // Main constructor for Room and new property creation logic
    public Property(String name, String location, int price, int beds, int baths, int sqft, String description, String imageUrl, boolean isFavorite, String userEmail) {
        this.name = name;
        this.location = location;
        this.price = price;
        this.beds = beds;
        this.baths = baths;
        this.sqft = sqft;
        this.description = description;
        this.imageUrl = imageUrl;
        this.isFavorite = isFavorite;
        this.userEmail = userEmail;
    }

    // Overloaded constructor for compatibility with old HomeActivity dummy data (9 parameters)
    // Room will ignore this constructor
    @Ignore
    public Property(int id, String name, String location, int price, int beds, int baths, int sqft, String description, String imageUrl) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.price = price;
        this.beds = beds;
        this.baths = baths;
        this.sqft = sqft;
        this.description = description;
        this.imageUrl = imageUrl;
        this.isFavorite = false; // Default favorite to false
        this.userEmail = null;   // Default userEmail to null
    }

    // Overloaded constructor for compatibility with old HomeActivity dummy data (8 parameters, description missing)
    // Room will ignore this constructor
    @Ignore
    public Property(int id, String name, String location, int price, int beds, int baths, int sqft, String imageUrl) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.price = price;
        this.beds = beds;
        this.baths = baths;
        this.sqft = sqft;
        this.description = "N/A"; // Default description
        this.imageUrl = imageUrl;
        this.isFavorite = false; // Default favorite to false
        this.userEmail = null;   // Default userEmail to null
    }


    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public int getPrice() {
        return price;
    }

    public int getBeds() {
        return beds;
    }

    public int getBaths() {
        return baths;
    }

    public int getSqft() {
        return sqft;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public String getUserEmail() { return userEmail; }


    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setBeds(int beds) {
        this.beds = beds;
    }

    public void setBaths(int baths) {
        this.baths = baths;
    }

    public void setSqft(int sqft) {
        this.sqft = sqft;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }

    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }
}
