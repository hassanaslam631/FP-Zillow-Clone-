package com.example.zillowclone.data.model;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Marks this class as a Room entity (table)
@Entity(tableName = "users")
public class User {
    @PrimaryKey // Email is the primary key
    @NonNull    // Email cannot be null
    private String email;
    private String password;

    // Constructor
    public User(@NonNull String email, String password) {
        this.email = email;
        this.password = password;
    }

    // Getters
    @NonNull
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    // Setters (if needed, though often primary keys are not changed)
    public void setEmail(@NonNull String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
