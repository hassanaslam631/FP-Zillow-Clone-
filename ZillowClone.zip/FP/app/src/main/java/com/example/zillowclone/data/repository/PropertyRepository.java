package com.example.zillowclone.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.zillowclone.ZillowCloneApp;
import com.example.zillowclone.data.dao.PropertyDao;
import com.example.zillowclone.data.model.Property;
import com.google.common.util.concurrent.ListenableFuture;


import java.util.List;
import java.util.concurrent.ExecutorService;

// Repository for managing Property data operations
public class PropertyRepository {
    private final PropertyDao propertyDao;
    private final ExecutorService executorService;

    public PropertyRepository(Application application) {
        ZillowCloneApp app = (ZillowCloneApp) application;
        propertyDao = app.getDatabase().propertyDao();
        executorService = app.databaseWriteExecutor;
    }

    // Get all properties
    public LiveData<List<Property>> getAllProperties() {
        return propertyDao.getAllProperties();
    }

    // Get favorite properties for a user
    public LiveData<List<Property>> getFavoriteProperties(String userEmail) {
        return propertyDao.getFavoriteProperties(userEmail);
    }

    // Get a single property by ID
    public LiveData<Property> getPropertyById(int propertyId) {
        return propertyDao.getPropertyById(propertyId);
    }

    // Get a single property by ID using ListenableFuture
    public ListenableFuture<Property> getPropertyByIdFuture(int propertyId) {
        return propertyDao.getPropertyByIdFuture(propertyId);
    }


    // Insert a property
    public void insert(Property property) {
        executorService.execute(() -> propertyDao.insert(property));
    }

    // Update a property
    public void update(Property property) {
        executorService.execute(() -> propertyDao.update(property));
    }

    // Search properties
    public LiveData<List<Property>> searchProperties(String query) {
        // The query needs to be formatted for LIKE SQL statements
        return propertyDao.searchProperties("%" + query + "%");
    }

    // Toggle favorite status of a property
    public void toggleFavorite(int propertyId, String userEmail) {
        executorService.execute(() -> {
            // This is a simplified toggle. In a real app, you might fetch first.
            // For Room, it's often easier to fetch the item, modify it, then update.
            // However, a direct update query in DAO could also work if Property had a userEmail field for favorites.
            // Here, we assume 'isFavorite' and 'userEmail' on Property are used.
            ListenableFuture<Property> futureProperty = propertyDao.getPropertyByIdFuture(propertyId);
            try {
                Property property = futureProperty.get(); // Blocking call, run on executor
                if (property != null) {
                    if (property.isFavorite() && property.getUserEmail() != null && property.getUserEmail().equals(userEmail)) {
                        property.setFavorite(false);
                        property.setUserEmail(null); // Or keep userEmail if property can be favorited by multiple users
                    } else {
                        property.setFavorite(true);
                        property.setUserEmail(userEmail);
                    }
                    propertyDao.update(property);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    public void addInitialPropertiesIfNeeded() {
        executorService.execute(() -> {
            // Check if properties already exist to avoid duplicates
            // This is a simplified check; you might want a more robust way
            if (propertyDao.getAllProperties().getValue() == null || propertyDao.getAllProperties().getValue().isEmpty()) {
                Property p1 = new Property("Luxury Villa", "DHA Phase 5, Lahore", 120000000, 5, 6, 5000, "Spacious villa with modern amenities.", "https://placehold.co/600x400/E0E7FF/4338CA?text=Villa+1", false, null);
                Property p2 = new Property("Studio Apartment", "Bahria Town, Lahore", 15000000, 1, 1, 600, "Cozy studio, great for singles.", "https://placehold.co/600x400/D1FAE5/065F46?text=Apartment+2", false, null);
                Property p3 = new Property("Farmhouse", "Raiwind Road, Lahore", 75000000, 4, 5, 8000, "Large farmhouse with a pool.", "https://placehold.co/600x400/FEF2F2/991B1B?text=Farmhouse+3", false, null);
                propertyDao.insert(p1);
                propertyDao.insert(p2);
                propertyDao.insert(p3);
            }
        });
    }
}
