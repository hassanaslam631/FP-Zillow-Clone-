package com.example.zillowclone.data.repository;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.example.zillowclone.ZillowCloneApp;
import com.example.zillowclone.data.dao.UserDao;
import com.example.zillowclone.data.model.User;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.ExecutorService;

// Repository for managing User data operations
public class UserRepository {
    private final UserDao userDao;
    private final ExecutorService executorService;
    private final SharedPreferences sharedPreferences;
    private final Application application;


    public UserRepository(Application application) {
        this.application = application;
        ZillowCloneApp app = (ZillowCloneApp) application;
        userDao = app.getDatabase().userDao();
        executorService = app.databaseWriteExecutor;
        sharedPreferences = application.getSharedPreferences(ZillowCloneApp.PREFS_NAME, Application.MODE_PRIVATE);
    }

    // Register a new user
    public void registerUser(User user, RegistrationCallback callback) {
        executorService.execute(() -> {
            try {
                // Check if user already exists
                User existingUser = userDao.getUserByEmail(user.getEmail()).get(); // Blocking, but on executor
                if (existingUser == null) {
                    userDao.insert(user);
                    callback.onSuccess();
                } else {
                    callback.onFailure("Email already exists.");
                }
            } catch (Exception e) {
                callback.onFailure(e.getMessage());
            }
        });
    }

    // Login a user
    public void loginUser(String email, String password, LoginCallback callback) {
        executorService.execute(() -> {
            try {
                User user = userDao.getUser(email, password).get(); // Blocking, but on executor
                if (user != null) {
                    // Save logged-in user's email
                    sharedPreferences.edit().putString(ZillowCloneApp.PREF_USER_EMAIL, email).apply();
                    callback.onSuccess(user);
                } else {
                    callback.onFailure("Invalid email or password.");
                }
            } catch (Exception e) {
                callback.onFailure(e.getMessage());
            }
        });
    }

    // Logout user
    public void logoutUser() {
        sharedPreferences.edit().remove(ZillowCloneApp.PREF_USER_EMAIL).apply();
    }

    // Get current logged-in user's email
    public String getCurrentUserEmail() {
        return sharedPreferences.getString(ZillowCloneApp.PREF_USER_EMAIL, null);
    }

    // Check if a user is currently logged in
    public boolean isUserLoggedIn() {
        return getCurrentUserEmail() != null;
    }


    // Callbacks for async operations
    public interface RegistrationCallback {
        void onSuccess();
        void onFailure(String message);
    }

    public interface LoginCallback {
        void onSuccess(User user);
        void onFailure(String message);
    }
}
