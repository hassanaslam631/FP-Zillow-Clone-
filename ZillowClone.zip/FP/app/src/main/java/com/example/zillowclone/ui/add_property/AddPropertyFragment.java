package com.example.zillowclone.ui.add_property;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.example.zillowclone.R;
import com.example.zillowclone.databinding.FragmentAddPropertyBinding;

public class AddPropertyFragment extends Fragment {

    private FragmentAddPropertyBinding binding;
    private AddPropertyViewModel addPropertyViewModel;
    private NavController navController;

    // ActivityResultLauncher for picking an image
    private final ActivityResultLauncher<Intent> pickImageLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null && result.getData().getData() != null) {
                    Uri imageUri = result.getData().getData();
                    addPropertyViewModel.setSelectedImageUri(imageUri);
                }
            });

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAddPropertyBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        addPropertyViewModel = new ViewModelProvider(this).get(AddPropertyViewModel.class);
        navController = Navigation.findNavController(view);

        // Observe selected image URI
        addPropertyViewModel.getSelectedImageUri().observe(getViewLifecycleOwner(), uri -> {
            if (uri != null) {
                Glide.with(this).load(uri).placeholder(R.drawable.placeholder).into(binding.imagePreview);
            }
        });

        // Observe add property result
        addPropertyViewModel.getAddPropertyResult().observe(getViewLifecycleOwner(), result -> {
            if (result == null) return;
            binding.progressBarAddProperty.setVisibility(View.GONE);
            if (result.getError() != null) {
                Toast.makeText(getContext(), result.getError(), Toast.LENGTH_LONG).show();
            }
            if (result.getSuccess() != null && result.getSuccess()) {
                Toast.makeText(getContext(), "Property Added Successfully!", Toast.LENGTH_SHORT).show();
                navController.popBackStack(); // Go back to the previous screen (e.g., Home)
            }
        });

        addPropertyViewModel.getIsLoading().observe(getViewLifecycleOwner(), isLoading -> {
            binding.progressBarAddProperty.setVisibility(isLoading ? View.VISIBLE : View.GONE);
            binding.addPropertyButton.setEnabled(!isLoading);
            binding.selectImageButton.setEnabled(!isLoading);
        });


        binding.selectImageButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            pickImageLauncher.launch(intent);
        });

        binding.addPropertyButton.setOnClickListener(v -> {
            String name = binding.nameInputEditText.getText().toString().trim();
            String location = binding.locationInputEditText.getText().toString().trim();
            String price = binding.priceInputEditText.getText().toString().trim();
            String beds = binding.bedsInputEditText.getText().toString().trim();
            String baths = binding.bathsInputEditText.getText().toString().trim();
            String sqft = binding.sqftInputEditText.getText().toString().trim();
            String description = binding.descInputEditText.getText().toString().trim();

            binding.progressBarAddProperty.setVisibility(View.VISIBLE);
            addPropertyViewModel.addProperty(name, location, price, beds, baths, sqft, description);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
