package com.example.zillowclone.ui.add_property;

import android.app.Application;
import android.net.Uri;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.zillowclone.data.model.Property;
import com.example.zillowclone.data.repository.PropertyRepository;
import com.example.zillowclone.data.repository.UserRepository;


public class AddPropertyViewModel extends AndroidViewModel {

    private final PropertyRepository propertyRepository;
    private final UserRepository userRepository;
    private final MutableLiveData<AddPropertyResult> addPropertyResult = new MutableLiveData<>();
    private final MutableLiveData<Uri> selectedImageUri = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);


    public AddPropertyViewModel(@NonNull Application application) {
        super(application);
        propertyRepository = new PropertyRepository(application);
        userRepository = new UserRepository(application);
    }

    public LiveData<AddPropertyResult> getAddPropertyResult() {
        return addPropertyResult;
    }

    public LiveData<Uri> getSelectedImageUri() {
        return selectedImageUri;
    }
    public LiveData<Boolean> getIsLoading() { return isLoading; }


    public void setSelectedImageUri(Uri uri) {
        selectedImageUri.setValue(uri);
    }

    public void addProperty(String name, String location, String priceStr, String bedsStr, String bathsStr, String sqftStr, String description) {
        // Basic Validation
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(location) || TextUtils.isEmpty(priceStr) ||
                TextUtils.isEmpty(bedsStr) || TextUtils.isEmpty(bathsStr) || TextUtils.isEmpty(sqftStr) ||
                TextUtils.isEmpty(description)) {
            addPropertyResult.setValue(new AddPropertyResult("All fields are required."));
            return;
        }
        if (selectedImageUri.getValue() == null) {
            addPropertyResult.setValue(new AddPropertyResult("Please select an image."));
            return;
        }

        try {
            int price = Integer.parseInt(priceStr);
            int beds = Integer.parseInt(bedsStr);
            int baths = Integer.parseInt(bathsStr);
            int sqft = Integer.parseInt(sqftStr);
            String imageUrl = selectedImageUri.getValue().toString(); // Using URI as string for now
            String currentUserEmail = userRepository.getCurrentUserEmail(); // Get current user

            Property property = new Property(name, location, price, beds, baths, sqft, description, imageUrl, false, currentUserEmail);

            isLoading.setValue(true);
            propertyRepository.insert(property); // Room operations are async via Executor in repository
            // Simulate success after a short delay as Room insert is fast
            // In a real app with network calls, you'd have callbacks from repository
            getApplication().getMainExecutor().execute(() -> { // Post to main thread
                isLoading.postValue(false);
                addPropertyResult.postValue(new AddPropertyResult(true));
            });


        } catch (NumberFormatException e) {
            addPropertyResult.setValue(new AddPropertyResult("Invalid number format for price, beds, baths, or sqft."));
        }
    }


    public static class AddPropertyResult {
        private Boolean success;
        private String error;

        AddPropertyResult(boolean success) {
            this.success = success;
        }

        AddPropertyResult(String error) {
            this.error = error;
        }

        public Boolean getSuccess() {
            return success;
        }

        public String getError() {
            return error;
        }
    }
}
