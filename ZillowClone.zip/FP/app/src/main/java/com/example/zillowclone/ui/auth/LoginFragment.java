package com.example.zillowclone.ui.auth;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.zillowclone.R;
import com.example.zillowclone.databinding.FragmentLoginBinding; // Generated ViewBinding class

// Fragment for user login
public class LoginFragment extends Fragment {

    private FragmentLoginBinding binding; // ViewBinding instance
    private LoginViewModel loginViewModel;
    private NavController navController;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment using ViewBinding
        binding = FragmentLoginBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        loginViewModel = new ViewModelProvider(this).get(LoginViewModel.class);
        navController = Navigation.findNavController(view);

        // Observe login results
        loginViewModel.getLoginResult().observe(getViewLifecycleOwner(), loginResult -> {
            if (loginResult == null) {
                return;
            }
            binding.progressBarLogin.setVisibility(View.GONE);
            if (loginResult.getError() != null) {
                Toast.makeText(getContext(), loginResult.getError(), Toast.LENGTH_LONG).show();
            }
            if (loginResult.getSuccess() != null) {
                Toast.makeText(getContext(), "Login Successful!", Toast.LENGTH_SHORT).show();
                // Navigate to home screen or main part of the app
                navController.navigate(R.id.action_loginFragment_to_homeFragment);
            }
        });

        loginViewModel.getIsLoading().observe(getViewLifecycleOwner(), isLoading -> {
            binding.progressBarLogin.setVisibility(isLoading ? View.VISIBLE : View.GONE);
            binding.loginButton.setEnabled(!isLoading);
            binding.goToSignupButton.setEnabled(!isLoading);
        });


        // Set up login button click listener
        binding.loginButton.setOnClickListener(v -> {
            String email = binding.emailLoginEditText.getText().toString().trim();
            String password = binding.passwordLoginEditText.getText().toString().trim();
            binding.progressBarLogin.setVisibility(View.VISIBLE);
            loginViewModel.login(email, password);
        });

        // Set up "Go to Signup" button click listener
        binding.goToSignupButton.setOnClickListener(v -> {
            // Navigate to SignupFragment
            navController.navigate(R.id.action_loginFragment_to_signupFragment);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Release binding to avoid memory leaks
    }
}
