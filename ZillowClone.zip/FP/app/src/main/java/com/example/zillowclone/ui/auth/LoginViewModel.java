package com.example.zillowclone.ui.auth;

import android.app.Application;
import android.util.Patterns;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.zillowclone.data.model.User;
import com.example.zillowclone.data.repository.UserRepository;

// ViewModel for Login functionality
public class LoginViewModel extends AndroidViewModel {
    private final UserRepository userRepository;
    private final MutableLiveData<LoginResult> loginResult = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);


    public LoginViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
    }

    public LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }
    public LiveData<Boolean> getIsLoading() { return isLoading; }


    public void login(String email, String password) {
        if (!isValidEmail(email)) {
            loginResult.setValue(new LoginResult("Invalid email format."));
            return;
        }
        if (password.isEmpty()) {
            loginResult.setValue(new LoginResult("Password cannot be empty."));
            return;
        }
        isLoading.setValue(true);
        userRepository.loginUser(email, password, new UserRepository.LoginCallback() {
            @Override
            public void onSuccess(User user) {
                isLoading.postValue(false);
                loginResult.postValue(new LoginResult(user));
            }

            @Override
            public void onFailure(String message) {
                isLoading.postValue(false);
                loginResult.postValue(new LoginResult(message));
            }
        });
    }

    private boolean isValidEmail(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    // Class to represent login result (success with user data or error message)
    public static class LoginResult {
        private User success;
        private String error;

        LoginResult(User success) {
            this.success = success;
        }

        LoginResult(String error) {
            this.error = error;
        }

        public User getSuccess() {
            return success;
        }

        public String getError() {
            return error;
        }
    }
}
