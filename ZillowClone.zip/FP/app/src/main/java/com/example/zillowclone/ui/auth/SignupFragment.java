package com.example.zillowclone.ui.auth;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.zillowclone.R;
import com.example.zillowclone.databinding.FragmentSignupBinding; // Generated ViewBinding class

// Fragment for user signup
public class SignupFragment extends Fragment {

    private FragmentSignupBinding binding; // ViewBinding instance
    private SignupViewModel signupViewModel;
    private NavController navController;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment using ViewBinding
        binding = FragmentSignupBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        signupViewModel = new ViewModelProvider(this).get(SignupViewModel.class);
        navController = Navigation.findNavController(view);

        // Observe signup results
        signupViewModel.getSignupResult().observe(getViewLifecycleOwner(), signupResult -> {
            if (signupResult == null) {
                return;
            }
            binding.progressBarSignup.setVisibility(View.GONE);
            if (signupResult.getError() != null) {
                Toast.makeText(getContext(), signupResult.getError(), Toast.LENGTH_LONG).show();
            }
            if (signupResult.getSuccess() != null && signupResult.getSuccess()) {
                Toast.makeText(getContext(), "Signup Successful! Please login.", Toast.LENGTH_SHORT).show();
                // Navigate to LoginFragment
                navController.navigate(R.id.action_signupFragment_to_loginFragment);
            }
        });

        signupViewModel.getIsLoading().observe(getViewLifecycleOwner(), isLoading -> {
            binding.progressBarSignup.setVisibility(isLoading ? View.VISIBLE : View.GONE);
            binding.signupButton.setEnabled(!isLoading);
            binding.goToLoginButton.setEnabled(!isLoading);
        });

        // Set up signup button click listener
        binding.signupButton.setOnClickListener(v -> {
            String email = binding.emailSignupEditText.getText().toString().trim();
            String password = binding.passwordSignupEditText.getText().toString().trim();
            String confirmPassword = binding.confirmPasswordSignupEditText.getText().toString().trim();
            binding.progressBarSignup.setVisibility(View.VISIBLE);
            signupViewModel.signup(email, password, confirmPassword);
        });

        // Set up "Go to Login" button click listener
        binding.goToLoginButton.setOnClickListener(v -> {
            // Navigate back to LoginFragment
            navController.navigate(R.id.action_signupFragment_to_loginFragment);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Release binding to avoid memory leaks
    }
}
