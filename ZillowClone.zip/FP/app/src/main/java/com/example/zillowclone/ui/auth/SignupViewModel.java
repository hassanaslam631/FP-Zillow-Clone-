package com.example.zillowclone.ui.auth;

import android.app.Application;
import android.util.Patterns;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.zillowclone.data.model.User;
import com.example.zillowclone.data.repository.UserRepository;

// ViewModel for Signup functionality
public class SignupViewModel extends AndroidViewModel {
    private final UserRepository userRepository;
    private final MutableLiveData<SignupResult> signupResult = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);

    public SignupViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
    }

    public LiveData<SignupResult> getSignupResult() {
        return signupResult;
    }
    public LiveData<Boolean> getIsLoading() { return isLoading; }


    public void signup(String email, String password, String confirmPassword) {
        if (!isValidEmail(email)) {
            signupResult.setValue(new SignupResult("Invalid email format."));
            return;
        }
        if (password.isEmpty() || password.length() < 6) {
            signupResult.setValue(new SignupResult("Password must be at least 6 characters."));
            return;
        }
        if (!password.equals(confirmPassword)) {
            signupResult.setValue(new SignupResult("Passwords do not match."));
            return;
        }

        isLoading.setValue(true);
        User newUser = new User(email, password); // In a real app, hash the password
        userRepository.registerUser(newUser, new UserRepository.RegistrationCallback() {
            @Override
            public void onSuccess() {
                isLoading.postValue(false);
                signupResult.postValue(new SignupResult(true)); // true indicates success
            }

            @Override
            public void onFailure(String message) {
                isLoading.postValue(false);
                signupResult.postValue(new SignupResult(message));
            }
        });
    }

    private boolean isValidEmail(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    // Class to represent signup result
    public static class SignupResult {
        private Boolean success; // Use Boolean to distinguish between not set, true, false
        private String error;

        SignupResult(boolean success) {
            this.success = success;
        }

        SignupResult(String error) {
            this.error = error;
        }

        public Boolean getSuccess() {
            return success;
        }

        public String getError() {
            return error;
        }
    }
}
