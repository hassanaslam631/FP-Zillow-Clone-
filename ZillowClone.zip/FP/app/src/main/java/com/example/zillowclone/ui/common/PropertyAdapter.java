package com.example.zillowclone.ui.common;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.zillowclone.R;
import com.example.zillowclone.data.model.Property;
import com.example.zillowclone.databinding.PropertyItemBinding; // Generated ViewBinding class

import java.text.NumberFormat;
import java.util.Locale;

// Adapter for displaying properties in a RecyclerView
public class PropertyAdapter extends ListAdapter<Property, PropertyAdapter.PropertyViewHolder> {

    private final OnPropertyClickListener onPropertyClickListener;
    private final OnFavoriteClickListener onFavoriteClickListener;
    private final String currentUserEmail; // To determine if the current user favorited the item

    // Interface for click events
    public interface OnPropertyClickListener {
        void onPropertyClick(Property property);
    }
    public interface OnFavoriteClickListener {
        void onFavoriteClick(Property property);
    }


    public PropertyAdapter(OnPropertyClickListener onPropertyClickListener, OnFavoriteClickListener onFavoriteClickListener, String currentUserEmail) {
        super(DIFF_CALLBACK);
        this.onPropertyClickListener = onPropertyClickListener;
        this.onFavoriteClickListener = onFavoriteClickListener;
        this.currentUserEmail = currentUserEmail;
    }

    // DiffUtil callback for efficient list updates
    private static final DiffUtil.ItemCallback<Property> DIFF_CALLBACK = new DiffUtil.ItemCallback<Property>() {
        @Override
        public boolean areItemsTheSame(@NonNull Property oldItem, @NonNull Property newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Property oldItem, @NonNull Property newItem) {
            // Check all relevant fields for changes
            return oldItem.getName().equals(newItem.getName()) &&
                    oldItem.getLocation().equals(newItem.getLocation()) &&
                    oldItem.getPrice() == newItem.getPrice() &&
                    oldItem.getBeds() == newItem.getBeds() &&
                    oldItem.getBaths() == newItem.getBaths() &&
                    oldItem.getSqft() == newItem.getSqft() &&
                    oldItem.getImageUrl().equals(newItem.getImageUrl()) &&
                    oldItem.isFavorite() == newItem.isFavorite() &&
                    (oldItem.getUserEmail() != null ? oldItem.getUserEmail().equals(newItem.getUserEmail()) : newItem.getUserEmail() == null);
        }
    };

    @NonNull
    @Override
    public PropertyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout using ViewBinding
        PropertyItemBinding binding = PropertyItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new PropertyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PropertyViewHolder holder, int position) {
        Property currentProperty = getItem(position);
        holder.bind(currentProperty, onPropertyClickListener, onFavoriteClickListener, currentUserEmail);
    }

    // ViewHolder class
    static class PropertyViewHolder extends RecyclerView.ViewHolder {
        private final PropertyItemBinding binding; // ViewBinding instance for the item layout

        public PropertyViewHolder(PropertyItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        // Bind data to the views
        public void bind(Property property, OnPropertyClickListener propertyClickListener, OnFavoriteClickListener favoriteClickListener, String currentUserEmail) {
            binding.textViewPropertyName.setText(property.getName());
            binding.textViewPropertyLocation.setText(property.getLocation());

            // Format price with currency
            NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "PK")); // For PKR
            binding.textViewPropertyPrice.setText(currencyFormat.format(property.getPrice()));

            Context context = binding.getRoot().getContext();
            binding.textViewPropertyBeds.setText(context.getString(R.string.beds_format, property.getBeds()));
            binding.textViewPropertyBaths.setText(context.getString(R.string.baths_format, property.getBaths()));
            binding.textViewPropertySqft.setText(context.getString(R.string.sqft_format, property.getSqft()));


            // Load image using Glide
            Glide.with(binding.getRoot().getContext())
                    .load(property.getImageUrl())
                    .placeholder(R.drawable.placeholder) // Placeholder image
                    .error(R.drawable.placeholder) // Error image if loading fails
                    .into(binding.imageViewProperty);

            // Set favorite button state
            // Check if the property is favorited by the current user
            boolean isFavoritedByCurrentUser = property.isFavorite() && property.getUserEmail() != null && property.getUserEmail().equals(currentUserEmail);
            if (isFavoritedByCurrentUser) {
                binding.buttonFavorite.setImageResource(R.drawable.ic_heart_filled);
                binding.buttonFavorite.setColorFilter(ContextCompat.getColor(context, R.color.red));
            } else {
                binding.buttonFavorite.setImageResource(R.drawable.ic_heart_outline);
                binding.buttonFavorite.setColorFilter(ContextCompat.getColor(context, R.color.gray)); // Or your outline color
            }


            // Set click listener for the item
            binding.getRoot().setOnClickListener(v -> propertyClickListener.onPropertyClick(property));
            // Set click listener for the favorite button
            binding.buttonFavorite.setOnClickListener(v -> favoriteClickListener.onFavoriteClick(property));
        }
    }
}
