package com.example.zillowclone.ui.favorites;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.zillowclone.R;
import com.example.zillowclone.data.model.Property;
import com.example.zillowclone.databinding.FragmentFavoritesBinding;
import com.example.zillowclone.ui.common.PropertyAdapter;

public class FavoritesFragment extends Fragment implements PropertyAdapter.OnPropertyClickListener, PropertyAdapter.OnFavoriteClickListener {

    private FragmentFavoritesBinding binding;
    private FavoritesViewModel favoritesViewModel;
    private PropertyAdapter propertyAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentFavoritesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        favoritesViewModel = new ViewModelProvider(this).get(FavoritesViewModel.class);

        setupRecyclerView();
        observeViewModel();
        setupSwipeRefresh();
    }

    private void setupRecyclerView() {
        propertyAdapter = new PropertyAdapter(this, this, favoritesViewModel.getCurrentUserEmail());
        binding.recyclerViewFavorites.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerViewFavorites.setAdapter(propertyAdapter);
    }

    private void setupSwipeRefresh() {
        binding.swipeRefreshLayoutFavorites.setOnRefreshListener(() -> {
            favoritesViewModel.refreshFavorites(); // ViewModel handles the refresh logic
        });
    }


    private void observeViewModel() {
        favoritesViewModel.getFavoriteProperties().observe(getViewLifecycleOwner(), properties -> {
            if (properties != null) {
                propertyAdapter.submitList(properties);
                binding.textViewNoFavorites.setVisibility(properties.isEmpty() ? View.VISIBLE : View.GONE);
            }
            binding.progressBarFavorites.setVisibility(View.GONE);
            binding.swipeRefreshLayoutFavorites.setRefreshing(false);
        });

        favoritesViewModel.getIsLoading().observe(getViewLifecycleOwner(), isLoading -> {
            if (!binding.swipeRefreshLayoutFavorites.isRefreshing()) {
                binding.progressBarFavorites.setVisibility(isLoading ? View.VISIBLE : View.GONE);
            }
        });
    }

    @Override
    public void onPropertyClick(Property property) {
        Toast.makeText(getContext(), "Clicked favorite: " + property.getName(), Toast.LENGTH_SHORT).show();
        // Navigate to details if needed
    }

    @Override
    public void onFavoriteClick(Property property) {
        // In favorites screen, clicking the heart typically means "unfavorite"
        favoritesViewModel.toggleFavorite(property);
        // Adapter will be updated via LiveData observation
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
