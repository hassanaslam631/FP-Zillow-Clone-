package com.example.zillowclone.ui.favorites;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.zillowclone.data.model.Property;
import com.example.zillowclone.data.repository.PropertyRepository;
import com.example.zillowclone.data.repository.UserRepository;

import java.util.List;

public class FavoritesViewModel extends AndroidViewModel {

    private final PropertyRepository propertyRepository;
    private final UserRepository userRepository;
    private final LiveData<List<Property>> favoriteProperties;
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);


    public FavoritesViewModel(@NonNull Application application) {
        super(application);
        propertyRepository = new PropertyRepository(application);
        userRepository = new UserRepository(application);
        String currentUserEmail = userRepository.getCurrentUserEmail();
        if (currentUserEmail != null) {
            favoriteProperties = propertyRepository.getFavoriteProperties(currentUserEmail);
        } else {
            // Handle case where user is not logged in, though ideally this screen shouldn't be accessible
            favoriteProperties = new MutableLiveData<>(); // Empty LiveData
        }
    }

    public LiveData<List<Property>> getFavoriteProperties() {
        return favoriteProperties;
    }
    public LiveData<Boolean> getIsLoading() { return isLoading; }


    public String getCurrentUserEmail() {
        return userRepository.getCurrentUserEmail();
    }

    public void toggleFavorite(Property property) {
        String userEmail = getCurrentUserEmail();
        if (userEmail != null) {
            // In favorites, clicking favorite usually means un-favoriting
            propertyRepository.toggleFavorite(property.getId(), userEmail);
        }
    }

    public void refreshFavorites() {
        // LiveData from Room automatically updates.
        // This method is here if manual refresh logic (e.g., from network) is needed in the future.
        // For SwipeRefreshLayout, we just need to manage its refreshing state.
        isLoading.setValue(true); // Or a specific swipe refreshing LiveData
        // Simulate data refresh
        isLoading.postValue(false);
    }
}
