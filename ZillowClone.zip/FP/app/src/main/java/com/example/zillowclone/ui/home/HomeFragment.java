package com.example.zillowclone.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView; // Use android.widget.SearchView
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.zillowclone.R;
import com.example.zillowclone.data.model.Property;
import com.example.zillowclone.databinding.FragmentHomeBinding; // Generated ViewBinding class
import com.example.zillowclone.ui.common.PropertyAdapter;

// Fragment for displaying list of properties
public class HomeFragment extends Fragment implements PropertyAdapter.OnPropertyClickListener, PropertyAdapter.OnFavoriteClickListener {

    private FragmentHomeBinding binding; // ViewBinding instance
    private HomeViewModel homeViewModel;
    private PropertyAdapter propertyAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment using ViewBinding
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        setupRecyclerView();
        setupSearchView();
        setupSwipeRefresh();
        observeViewModel();
    }

    private void setupRecyclerView() {
        // Initialize adapter with the current user's email for favorite status
        propertyAdapter = new PropertyAdapter(this, this, homeViewModel.getCurrentUserEmail());
        binding.recyclerViewHome.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerViewHome.setAdapter(propertyAdapter);
    }

    private void setupSearchView() {
        binding.searchViewHome.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                homeViewModel.setSearchQuery(query);
                return true; // Query handled
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                homeViewModel.setSearchQuery(newText);
                return true; // Query handled
            }
        });
        // Handle search view close
        binding.searchViewHome.setOnCloseListener(() -> {
            homeViewModel.setSearchQuery(null); // Clear search query
            return false; // Allow default behavior (clear text, collapse)
        });
    }
    private void setupSwipeRefresh() {
        binding.swipeRefreshLayoutHome.setOnRefreshListener(() -> {
            homeViewModel.refreshProperties(); // ViewModel handles the refresh logic
        });
    }


    private void observeViewModel() {
        homeViewModel.getProperties().observe(getViewLifecycleOwner(), properties -> {
            if (properties != null) {
                propertyAdapter.submitList(properties);
                binding.textViewNoProperties.setVisibility(properties.isEmpty() ? View.VISIBLE : View.GONE);
            }
            binding.progressBarHome.setVisibility(View.GONE); // Hide progress bar after loading
            binding.swipeRefreshLayoutHome.setRefreshing(false); // Stop swipe refresh indicator
        });

        homeViewModel.getIsLoading().observe(getViewLifecycleOwner(), isLoading -> {
            if (!binding.swipeRefreshLayoutHome.isRefreshing()) { // Only show progress bar if not swipe refreshing
                binding.progressBarHome.setVisibility(isLoading ? View.VISIBLE : View.GONE);
            }
        });

        homeViewModel.getSwipeRefreshing().observe(getViewLifecycleOwner(), isRefreshing -> {
            binding.swipeRefreshLayoutHome.setRefreshing(isRefreshing);
        });
    }

    @Override
    public void onPropertyClick(Property property) {
        // Handle property click, e.g., navigate to property details screen
        Toast.makeText(getContext(), "Clicked: " + property.getName(), Toast.LENGTH_SHORT).show();
        // Example Navigation:
        // NavController navController = Navigation.findNavController(getView());
        // HomeFragmentDirections.ActionHomeFragmentToPropertyDetailFragment action =
        // HomeFragmentDirections.actionHomeFragmentToPropertyDetailFragment(property.getId());
        // navController.navigate(action);
    }

    @Override
    public void onFavoriteClick(Property property) {
        homeViewModel.toggleFavorite(property);
        // The LiveData observation will update the adapter automatically
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Release binding to avoid memory leaks
    }
}
