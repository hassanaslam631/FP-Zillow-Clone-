package com.example.zillowclone.ui.home;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.example.zillowclone.data.model.Property;
import com.example.zillowclone.data.repository.PropertyRepository;
import com.example.zillowclone.data.repository.UserRepository;

import java.util.List;

// ViewModel for Home screen
public class HomeViewModel extends AndroidViewModel {
    private final PropertyRepository propertyRepository;
    private final UserRepository userRepository;
    private final LiveData<List<Property>> allProperties;
    private final MutableLiveData<String> searchQuery = new MutableLiveData<>();
    private final LiveData<List<Property>> filteredProperties;
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> swipeRefreshing = new MutableLiveData<>(false);


    public HomeViewModel(@NonNull Application application) {
        super(application);
        propertyRepository = new PropertyRepository(application);
        userRepository = new UserRepository(application);
        allProperties = propertyRepository.getAllProperties(); // Observe all properties initially

        // Add initial properties if DB is empty
        propertyRepository.addInitialPropertiesIfNeeded();


        // Transformation to filter properties based on search query
        filteredProperties = Transformations.switchMap(searchQuery, query -> {
            if (query == null || query.isEmpty()) {
                return allProperties; // If no query, show all
            } else {
                return propertyRepository.searchProperties(query);
            }
        });

        // Initially, set search query to null to load all properties
        searchQuery.setValue(null);
    }

    public LiveData<List<Property>> getProperties() {
        return filteredProperties; // Return the filtered list
    }
    public LiveData<Boolean> getIsLoading() { return isLoading; }
    public LiveData<Boolean> getSwipeRefreshing() { return swipeRefreshing; }


    public void setSearchQuery(String query) {
        searchQuery.setValue(query);
    }

    public void refreshProperties() {
        // This might involve re-fetching from a remote source in a real app.
        // For Room, LiveData handles updates automatically.
        // If you need to manually trigger a re-fetch or clear cache, do it here.
        // For now, we can simulate a refresh for SwipeRefreshLayout
        swipeRefreshing.setValue(true);
        // Simulate network delay or data processing
        // In a real app, you'd call repository methods that fetch fresh data
        // For this example, LiveData will update if underlying data changes.
        // We just need to turn off the refreshing indicator.
        // A simple way for now is to just re-observe or post a value.
        searchQuery.setValue(searchQuery.getValue()); // Re-trigger the transformation
        swipeRefreshing.postValue(false); // Ensure this is on main thread if from background
    }

    public String getCurrentUserEmail() {
        return userRepository.getCurrentUserEmail();
    }

    public void toggleFavorite(Property property) {
        String userEmail = getCurrentUserEmail();
        if (userEmail != null) {
            propertyRepository.toggleFavorite(property.getId(), userEmail);
        }
    }
}
