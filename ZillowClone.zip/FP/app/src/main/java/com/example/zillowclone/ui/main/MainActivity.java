package com.example.zillowclone.ui.main;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider; // Keep for other potential uses
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.example.zillowclone.R;
import com.example.zillowclone.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding; // ViewBinding instance
    // MainViewModel can be kept if needed for other Activity-level logic in the future
    // private MainViewModel mainViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // mainViewModel = new ViewModelProvider(this).get(MainViewModel.class); // Keep if needed

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);
        if (navHostFragment != null) {
            NavController navController = navHostFragment.getNavController();

            NavigationUI.setupWithNavController(binding.bottomNav, navController);

            navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
                int destinationId = destination.getId();
                // Hide BottomNav for Login and Signup screens
                if (destinationId == R.id.loginFragment || destinationId == R.id.signupFragment) {
                    binding.bottomNavContainer.setVisibility(View.GONE);
                } else {
                    binding.bottomNavContainer.setVisibility(View.VISIBLE);
                }
            });

            // The NavGraph's startDestination (loginFragment) will be loaded automatically.
            // LoginFragment will handle navigation to HomeFragment if the user is already logged in.
        }
    }
}
