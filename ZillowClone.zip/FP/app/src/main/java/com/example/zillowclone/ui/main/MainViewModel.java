package com.example.zillowclone.ui.main;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import com.example.zillowclone.data.repository.UserRepository;

public class MainViewModel extends AndroidViewModel {
    private final UserRepository userRepository;

    public MainViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
    }

    public boolean isUserLoggedIn() {
        return userRepository.isUserLoggedIn();
    }

    public String getCurrentUserEmail() {
        return userRepository.getCurrentUserEmail();
    }
}
