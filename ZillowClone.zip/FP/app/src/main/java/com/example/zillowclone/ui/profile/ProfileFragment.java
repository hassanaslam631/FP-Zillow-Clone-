package com.example.zillowclone.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.zillowclone.R;
import com.example.zillowclone.databinding.FragmentProfileBinding;

public class ProfileFragment extends Fragment {

    private FragmentProfileBinding binding;
    private ProfileViewModel profileViewModel;
    private NavController navController;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        profileViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);
        navController = Navigation.findNavController(view);

        profileViewModel.getUserEmail().observe(getViewLifecycleOwner(), email -> {
            if (email != null) {
                binding.emailViewProfile.setText(getString(R.string.logged_in_as_format, email));
            } else {
                binding.emailViewProfile.setText(R.string.not_logged_in);
            }
        });

        profileViewModel.getIsDarkMode().observe(getViewLifecycleOwner(), darkModeEnabled -> {
            binding.themeSwitchProfile.setChecked(darkModeEnabled);
        });

        binding.themeSwitchProfile.setOnCheckedChangeListener((buttonView, isChecked) -> {
            profileViewModel.setDarkMode(isChecked);
            // The activity might need to be recreated to apply theme fully if not handled by AppCompatDelegate immediately.
            // For simple color changes, it might be okay. For full theme, activity recreation is safer.
            // getActivity().recreate(); // This can be disruptive, use with caution.
        });

        binding.logoutButtonProfile.setOnClickListener(v -> {
            profileViewModel.logout();
            // Navigate to login screen
            navController.navigate(R.id.action_profileFragment_to_loginFragment);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
