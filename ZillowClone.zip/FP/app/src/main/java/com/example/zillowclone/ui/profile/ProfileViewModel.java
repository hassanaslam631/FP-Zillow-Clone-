package com.example.zillowclone.ui.profile;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.zillowclone.ZillowCloneApp;
import com.example.zillowclone.data.repository.UserRepository;

public class ProfileViewModel extends AndroidViewModel {

    private final UserRepository userRepository;
    private final SharedPreferences sharedPreferences;
    private final MutableLiveData<String> userEmail = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isDarkMode = new MutableLiveData<>();

    public ProfileViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
        sharedPreferences = application.getSharedPreferences(ZillowCloneApp.PREFS_NAME, Application.MODE_PRIVATE);

        // Load initial values
        userEmail.setValue(userRepository.getCurrentUserEmail());
        isDarkMode.setValue(sharedPreferences.getBoolean(ZillowCloneApp.PREF_DARK_MODE, false));
    }

    public LiveData<String> getUserEmail() {
        return userEmail;
    }

    public LiveData<Boolean> getIsDarkMode() {
        return isDarkMode;
    }

    public void setDarkMode(boolean enabled) {
        sharedPreferences.edit().putBoolean(ZillowCloneApp.PREF_DARK_MODE, enabled).apply();
        isDarkMode.setValue(enabled);
        AppCompatDelegate.setDefaultNightMode(
                enabled ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
        );
    }

    public void logout() {
        userRepository.logoutUser();
        // Additional cleanup if needed, e.g., clear database cache for the user
    }
}
